/* This won't appear in Production bundle ! */

export var Add = (x, y) => x + y;

export class Point {
  constructor(x, y,z) {
    this.x = x;
    this.y = y;
  }
  printPoint() {
    console.log(`[X : ${this.x} , Y : ${this.y}]`);
  }
}
